package demo4;

import java.util.Scanner;

public class SanPham {
    //1.dinh nghia cac thuoc tinh (bien)
    public String tenSP;
    public double donGia;
    public double giamGia;
    //2.dinh nghia cac phuong thuc (ham)
    public double thueNhapKhau()
    {
        double tnk = donGia*0.1;//tinh toan
        return tnk;//tra ve ket qua
    }
    public void xuat()
    {
        System.out.println("Thong tin san pham vua nhap");
        System.out.println("Ten sp: "+tenSP);
        System.out.println("Don gia: "+donGia);
        System.out.println("Giam gia: "+giamGia);
        System.out.println("Thue nhap khau: "+thueNhapKhau());
    }
    //3. Hàm khởi tạo có chức năng tạo đối tượng mới cho lớp (đẻ)
    //Scanner s = new Scanner()
    //có thể dùng được từ khóa new (đẻ đối tượng) thì bắt buộc phải có hàm khởi tạo
    public SanPham()//hàm khởi tạo không có tham số
    {
    }
    public void nhap()
    {
        System.out.println("Moi nhap: Ten sp, Don gia, Giam gia");
        Scanner s = new Scanner(System.in);
        tenSP = s.nextLine();
        donGia = Double.parseDouble(s.nextLine());
        giamGia = Double.parseDouble(s.nextLine());
    }
}
