package demo4;

public class BaiXe {
    //biến (thuộc tính)
    public String MauSon;
    public String HangXe;
    public int SoBanh;
    //hàm (phương thức)
    public void di()
    {
        System.out.println("Xe đi thẳng, rẽ phải, rẽ trái");
    }
    public void no()
    {
        System.out.println("Xe nổ brum");
    }
}
