
package demo4;//toa nha demo4, toa nhà F, P, L

public class D4 {// lop D4;CP17316; trong lớp D4 sẽ có các sinh viên (đối tượng)
    public static void main(String[] args) {
        SanPham1 sp = new SanPham1();//tao moi doi tuong SP
        sp.nhap();//goi ham nhap cua doi tuong sp
        sp.xuat();//goi ham xuat cua doi tuong sp
    }
    
    
}
