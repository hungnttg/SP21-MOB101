
package demo3;

public class D3 {
    public static void main(String[] args) {
        Demo3 d = new Demo3();
        //d.kt_songuyento();
        //d.bangCuuChuong();
        //d.nhapXuatMang();
        d.mang_hoten_diem();
    }
}
