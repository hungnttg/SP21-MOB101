
package demo3;

import java.util.Scanner;
import java.util.Arrays;

public class Demo3 {
    public void kt_songuyento()
    {
        //1. Nhap lieu
        Scanner s = new Scanner(System.in);
        System.out.println("Kiem tra so nguyen to");
        System.out.println("a=");
        int a = s.nextInt();
        //2. Tinh toan
        boolean isSNT = true;
        int i=2;
        while(i<a)
        {
            if(a%i==0)//a chia het cho 1 so trong khoang 2->a
            {
                isSNT = false;
            }
            i++;
        }
        if(isSNT==true)
        {
            System.out.println(a+ " la so nguyen to");
        }
        else
        {
            System.out.println(a+ " khong phai la so nguyen to");
        }
        
    }
    public void bangCuuChuong()
    {
        for(int x=1;x<=10;x++)
        {
            System.out.println("---------");
            for(int i=1;i<=10;i++)
            {
                System.out.printf("%d x %d = %d\n",x,i,x*i);
            }
        }
    }
    public void nhapXuatMang()
    {
        System.out.println("Moi ban nhap mang so nguyen");
        Scanner s = new Scanner(System.in);
        //1. Tao moi mang gom 5 phan tu
        int[] a = new int[5]; 
        //2. Nhap du lieu vao mang (phai dung vong lap)
        for(int i=0;i<a.length;i++)
        {
            //Integer.parseInt(); chuyen du lieu nhap vao sang so nguyen
            //Double.parseDouble();chuyen du lieu nhap vao sang so thuc
            a[i] = Integer.parseInt(s.nextLine());
        }
        System.out.println("Mang ban vua nhap");
        //3. Doc du lieu tu mang
        for(int j=0;j<a.length;j++)
        {
            System.out.println(a[j]);//in ra man hinh tung phan tu mang
        }
        //4. sap xep lai mang
        Arrays.sort(a);
        //5. in mang sau khi sap xep
        System.out.println("Mang sau khi sap xep la");
        for(int k=0;k<a.length;k++)
        {
            System.out.println(a[k]);
        }
        //6. tinh trung binh cong cac so chia het cho 3
        int tong=0,dem = 0;
        for(int k=0;k<a.length;k++)
        {
            if(a[k]%3==0)
            {
                tong += a[k];
                dem++;
            }
        }
        float trungbinhcong = ((float)tong/dem);
        System.out.println("Trung binh cong cac so chia het cho 3 la "+trungbinhcong);
    }
    public void mang_hoten_diem()
    {
        System.out.println("Moi nhap ho ten va diem");
        Scanner s = new Scanner(System.in);//tao luong nhap
        String[] hoTen = new String[4];
        String[] hocLuc = new String[4];
        float[] diem = new float[4];
        //1. Nhap du lieu
        for(int i=0;i<hoTen.length;i++)
        {
            hoTen[i] = s.nextLine();//nhap ho ten tu ban phim
            diem[i] = Float.parseFloat(s.nextLine());//chuyen du lieu sang float, tuong duong s.nextFloat()
            if(diem[i]<5)
            {
                hocLuc[i] = "Yeu";
            }
            else if(diem[i]<6.5)
            {
                hocLuc[i] = "TB";
            }
            else if(diem[i]<7.5)
            {
                hocLuc[i] = "Kha";
            }
            else 
            {
                hocLuc[i] = "Gioi";
            }
        }
        //2. in ta man hinh cac thong tin vua nhap
        System.out.println("Ban vua nhap cac thong tin sau");
        for(int i=0;i<hoTen.length;i++)
        {
            System.out.printf("Ho ten: %s; Diem: %.1f; Hoc luc: %s \n",
                    hoTen[i],diem[i],hocLuc[i]);
        }
        //3. sap xep theo diem
        for(int i=0;i<hoTen.length-1;i++)//lay phan tu dau den phan tu gan cuoi
        {
            for(int j=i+1;j<hoTen.length;j++)//lay phan tu thu 2 den phan tu cuoi
            {
                if(diem[i]>diem[j])
                {
                    float tam = diem[i];
                    diem[i] = diem[j];
                    diem[j] = tam;
                    
                    String htTam = hoTen[i];
                    hoTen[i] = hoTen[j];
                    hoTen[j] = htTam;
                    
                    String hlTam = hocLuc[i];
                    hocLuc[i] = hocLuc[j];
                    hocLuc[j] = hlTam;
                }
            }
        }
        //4. in mang sau khi sap xep
        System.out.println("Mang sau khi sap xep theo diem la");
        for(int i=0;i<hoTen.length;i++)
        {
            System.out.printf("Ho ten: %s; Diem: %.1f; Hoc luc: %s \n",
                    hoTen[i],diem[i],hocLuc[i]);
        }
    }
}
