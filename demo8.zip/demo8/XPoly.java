
package demo8;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

final public class XPoly {
    public static double sum(double...ts)
    {
        double tong=0;
        for(double a: ts )
        {
            tong += a;
        }
        return tong;
    }
    public static double min(double...ts)
    {
        List<Double> ls = new ArrayList<>();//ls chua danh sach tham so
        for(double a: ts)
        {
            ls.add(a);//them tham so vao ls
        }
        Collections.sort(ls);//sap xep danh sach theo thu tu tu nho den lon
        return ls.get(0);
    }
    public static double max(double...ts)
    {
        List<Double> ls = new ArrayList<>();//ls chua danh sach tham so
        for(double a: ts)
        {
            ls.add(a);//them tham so vao ls
        }
        Collections.sort(ls);//sap xep danh sach theo thu tu tu nho den lon
        return ls.get(ls.size()-1);
    }
    public static String toUpperFirstChar(String str)
    {
        String[] mangs = str.split(" ");//cắt chuỗi theo dấu cách
        String chuoiMoi = "";
        for(int i=0;i<mangs.length;i++)
        {
            char kyTuDau = mangs[i].charAt(0);//lay ve ky tu dau
            char kyTuDauChuHoa = String.valueOf(kyTuDau).toUpperCase().charAt(0);
            mangs[i] = kyTuDauChuHoa+mangs[i].substring(1);
            chuoiMoi += mangs[i]+" ";
            
        }
        return chuoiMoi;
    }
}
