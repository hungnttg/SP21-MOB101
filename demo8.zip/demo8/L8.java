
package demo8;

public class L8 {
    public static void main(String[] args) {
        System.out.printf("Tong: %.1f\n",XPoly.sum(1,2,4,6));
        System.out.printf("Min: %.1f\n",XPoly.min(19,6,8,3));
        System.out.printf("Max: %.1f\n",XPoly.max(33,22,11,99,55));
        System.out.printf("Chuyen chu hoa: %s\n",
                XPoly.toUpperFirstChar("nguyen van an"));
    }
}
