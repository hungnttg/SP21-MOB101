package demo3;

import java.util.Scanner;
import java.util.Arrays;

public class Bai3 {
    public void ktSNT()
    {
        //1. Nhap lieu
        System.out.println("Moi ban nhap so a=");
        Scanner s = new Scanner(System.in);//tao luong nhap
        int a = s.nextInt();//nhap du lieu tu ban phim
        //2. Tinh toan
        boolean flag = true;//bien kiem tra snt
        int i=2;
        while(i<a)
        {
            if(a%i==0)//neu a chia het cho i
            {
                flag = false;//khong phai snt
                break;
            }
            i++;
        }
        //3. kiem tra
        if(flag==true)
        {
            System.out.println(a+" la so nguyen to");
        }
        else
        {
            System.out.println(a+" khong phai so nguyen to");
        }
    }
    public void bangCuuChuong()
    {
        for(int j=1;j<=10;j++)//tao ra 10 bang
        {
            System.out.println("-------------");
            for(int i=1;i<=10;i++)//moi bang tao ra 10 dong
            {
                System.out.printf("%d x %d = %d\n",j,i,j*i);
            }
        }
    }
    public void sapxep()
    {
        System.out.println("----Nhap mang so nguyen-----");
        Scanner s = new Scanner(System.in);
        int[] a = new int[5];//tao mang gom 5 phan tu de chua du lieu
        //1.Nhap lieu vao mang
        for(int i=0;i<a.length;i++)//a.length: chieu dai mang
        {
            a[i] = Integer.parseInt(s.nextLine());//nhap du lieu tu ban phim
        }
        System.out.println("----Ban vua nhap mang sau-----");
        //2. Doc du lieu tu mang
        for(int j=0;j<a.length;j++)
        {
            System.out.println(a[j]);//in từng phần tử mảng ra màn hình
        }
        //3. sap xep mang
        Arrays.sort(a);
        System.out.println("----Mang sau khi sap xep-----");
        //4. in ra mang sau khi sap xep
        for(int j=0;j<a.length;j++)
        {
            System.out.println(a[j]);//in từng phần tử mảng ra màn hình
        }
        //4. in ra thanh phan nho nhat
        System.out.println("----Thanh phan nho nhat-----");
        System.out.println(a[0]);//a[0] sau khi sap xep la thanh phan nho nhat
        //5. tinh trung binh cong cac so chia het cho 3
        int tong=0,dem=0;//trung binh cong bang tong/dem
        for(int k=0;k<a.length;k++)
        {
            if(a[k]%3==0)//a[k] chia het cho 3
            {
                tong += a[k];
                dem++;
            }
        }
        float tbc = ((float)tong/dem);
        System.out.println("Trung binh cong cac so chia het cho 3 la "+tbc);
    }
    public void hocluc()
    {
        System.out.println("Hay nhap ho ten va diem");
        Scanner s = new Scanner(System.in);//luong nhap
        String[] hoTen = new String[5];//tao mang hoTen
        String[] hocLuc = new String[5];//tao mang hocLuc
        float[] diem = new float[5];//tao mamg diem
        //1.Nhap du lieu
        for(int i=0;i<hoTen.length;i++)
        {
            hoTen[i] = s.nextLine();//nhap ho ten sv
            diem[i] = Float.parseFloat(s.nextLine());//nhap diem,chuyen sang so thuc
            if(diem[i]<5)
            {
                hocLuc[i]="Yeu";
            }
            else if(diem[i]<6.5)
            {
                hocLuc[i]="TB";
            }
            else if(diem[i]<7.5)
            {
                hocLuc[i]="Kha";
            }
            else if(diem[i]<9)
            {
                hocLuc[i]="Gioi";
            }
            else
            {
                hocLuc[i]="xuat sac";
            }
        }
        //2. In ra man hinh cac thong tin vua nhap
        System.out.println("----Thong tin cac sinh vien vua nhap--------");
        for(int i=0;i<hoTen.length;i++)
        {
            System.out.printf("Ho ten: %s; - Diem: %.1f; - Hoc luc: %s\n"
            ,hoTen[i],diem[i],hocLuc[i]);
        }
        //3. Sap xep theo diem sinh vien
        for(int i=0;i<hoTen.length-1;i++)//lay phan tu dau tien den pt gan cuoi cung
        {
            for(int j=i+1;j<hoTen.length;j++)//lay phan tu thu 2 den phan tu cuoi
            {
                if(diem[i]>diem[j])//doi cho
                {
                    float diemTam = diem[i];//doi cho diem
                    diem[i] = diem[j];
                    diem[j] = diemTam;
                    
                    String htTam = hoTen[i];//doi cho ho ten
                    hoTen[i] = hoTen[j];
                    hoTen[j] = htTam;
                    
                    String hoclucTam = hocLuc[i];
                    hocLuc[i] = hocLuc[j];
                    hocLuc[j] = hoclucTam;
                }
            }
        }
        System.out.println("-----Mang sau khi sap xep theo diem-------");
        for(int i=0;i<hoTen.length;i++)
        {
            System.out.printf("Ho ten: %s; - Diem: %.1f; - Hoc luc: %s\n"
            ,hoTen[i],diem[i],hocLuc[i]);
        }
    }
}
