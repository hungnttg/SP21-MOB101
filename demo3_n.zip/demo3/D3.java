
package demo3;

public class D3 {
    public static void main(String[] args) {
        Bai3 b = new Bai3();//tao moi doi tuong b
        //b.ktSNT();//goi ham ktSNT cua doi tuong b
        //b.bangCuuChuong();
        //b.sapxep();
        b.hocluc();
    }
}
