package demo2;

import java.util.Scanner;

public class D2 {
    
    public static void main(String[] args) {
        CP17318 sv1 = new CP17318();//tao moi doi tuong sv1
        //sv1.gptb1();//goi ham gptb1() cua lop CP17318
        //sv1.gptb2();//goi ham gptb2() cua lop CP17318
        //sv1.tinhtiendien();
        sv1.menu();
    }
}
