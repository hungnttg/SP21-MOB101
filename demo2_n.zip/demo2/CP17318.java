
package demo2;

import java.util.Scanner;


public class CP17318 {
    public void gptb1()//dinh nghia ham
    {
        Scanner s1 = new Scanner(System.in);
        //nhap he so
        System.out.println("a="); int a = s1.nextInt();
        System.out.println("b="); int b = s1.nextInt();
        //tinh toan
        float x = ((float)-b/a);
        System.out.println("Nghiem x="+x);
    }
    public void gptb2()
    {
        Scanner s = new Scanner(System.in);
        //nhap he so
        System.out.println("a="); int a = s.nextInt();
        System.out.println("b="); int b = s.nextInt();
        System.out.println("c="); int c = s.nextInt();
        //tinh toan
        float delta = b*b-4*a*c;
        if(a==0){
            System.out.println("Giai PTBac 1");
            gptb1();//goi ham gptb1
        }else{
            if(delta<0)
            {
                System.out.println("PTVN");
            }
            else if(delta==0)
            {
                System.out.println("PT co n kep x="+((float)-b/(2*a)));
            }
            else
            {
                float x1 = ((float)(-b+Math.sqrt(delta))/(2*a));
                float x2 = ((float)(-b-Math.sqrt(delta))/(2*a));
                System.out.println("2 nghiem x1="+x1);
                System.out.println(" va x1="+x2);
            }           
        }
        
    }
    public void tinhtiendien()
    {
        Scanner s5 = new Scanner(System.in);
        System.out.println("Nhap so dien=");
        double sodien = s5.nextDouble();
        //tinh toan
        double tongtien=0;
        if(sodien<50)
        {
            tongtien = sodien*1000;
        }
        else
        {
            tongtien = 50*1000+(sodien-50)*1200;
        }
        System.out.println("Tong tien dien la: "+tongtien);
    }
    public void menu()
    {
        System.out.println("Moi ban chon chuc nang");
        System.out.println("----------------------");
        System.out.println("1. giai phuong trinh bac 1");
        System.out.println("2. Giai phuong trinh bac 2");
        System.out.println("3. Tinh tien dien");
        System.out.println("----------------------");
        //--
        Scanner s = new Scanner(System.in);
        int chucnang = s.nextInt();
        switch(chucnang)
        {
            case 1:
                gptb1();
                break;
            case 2:
                gptb2();
                break;
            case 3:
                tinhtiendien();
                break;
            default:
                System.out.println("Khong co chuc nang vua nhap");
                break;
        }
    }
    
}
