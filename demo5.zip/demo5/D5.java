package demo5;

public class D5 {
    public static void main(String[] args) {
//        SoThuc st = new SoThuc();
//        st.nhapSoThuc();
//        st.xuatSoThuc();
            SinhVien sv = new SinhVien();
            sv.nhap();
            sv.xuat();
            sv.sapXepNhauNhien();
            sv.sapXepTangDan();
            sv.sapXepGiamDan();
    }
}
