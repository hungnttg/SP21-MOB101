
package demo5;

import java.util.ArrayList;
import java.util.Scanner;

public class SoThuc {
    private ArrayList<Double> ar;//khai bao bien
    public void nhapSoThuc()//khai bao ham1
    {
        ar = new ArrayList<>();//tao mang dong
        Scanner s = new Scanner(System.in);
        while(true)
        {
            Double a = s.nextDouble();//nhap lieu tu ban phim
            ar.add(a);//them vao mang dong
            s.nextLine();//lam sach luong dem
            System.out.println("Co nhap tiep khong? (Y/N)");
            String kq = s.nextLine();
            if(kq.equals("N"))//neu nhap N
            {
                break;//thoat khoi vong lap
            }
        }
    }
    public void xuatSoThuc()//khai bao ham 2
    {
        System.out.println("Mang dong vua nhap");
        for(Double x: ar)
        {
            System.out.println(x.toString());
        }
    }
    
}
