package demo5;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class SinhVien {
    private String hoTen;
    ////------bat dau code
    ArrayList<String> ar = new ArrayList<>();//mang luu ten sinh vien
    public void nhap()
    {
        Scanner s = new Scanner(System.in);
        String qd;//co nhap tiep khong?
        boolean yn=true;//bien dieu khien vong lap
        while(yn)//dua vao vong lap de nhap lieu
        {
            System.out.println("Nhap ho ten: ");
            hoTen = String.valueOf(s.nextLine());//nhap lieu tu ban phim
            ar.add(hoTen);//dua ho ten vao danh sach
            qd = String.valueOf(s.nextLine());//nhap Y hoac N
            switch(qd)
            {
                case "Y":
                    yn=true;//cho phep nhap tiep
                    break;
                case "N":
                    yn=false;//khong cho phep nhap tiep
                    break;
                default:
                    System.out.println("Hay nhap Y hoac N");
            }
            
        }
        System.err.println("-----Ket thuc nhap lieu---------");
    }
    public void xuat()
    {
        System.out.println("----------Danh sach sv vua nhap----------------");
        for(String x: ar)
        {
            System.out.println(x.toString());//toString: bien thanh chuoi
        }
    }
    public void sapXepNhauNhien()
    {
        System.out.println("----------Sap xep ngau nhien----------------");
        Collections.shuffle(ar);//sap xep ngau nhien
        for(String x: ar)
        {
            System.out.println(x.toString());//toString: bien thanh chuoi
        }
    }
    public void sapXepTangDan()
    {
        System.out.println("----------Sap xep tang dan----------------");
        Collections.sort(ar);//sap xep tang dan
        for(String x: ar)
        {
            System.out.println(x.toString());//toString: bien thanh chuoi
        }
    }
    public void sapXepGiamDan()
    {
        System.out.println("----------Sap xep Giam dan----------------");
        Collections.sort(ar);//sap xep tang dan
        Collections.reverse(ar);//sap xep dao nguoc
        for(String x: ar)
        {
            System.out.println(x.toString());//toString: bien thanh chuoi
        }
    }
    
    ///-------ket thuc code

    public SinhVien() {
    }

    public SinhVien(String hoTen) {
        this.hoTen = hoTen;
    }

    public String getHoTen() {
        return hoTen;
    }

    public void setHoTen(String hoTen) {
        this.hoTen = hoTen;
    }
    
}
