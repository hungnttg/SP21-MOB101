
package demo7;

public interface InterfaceSV {
    public double getDiemTB();
    public void nhap();
    public void xuat();
}
