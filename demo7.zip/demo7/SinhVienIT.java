
package demo7;

import java.util.Scanner;

public class SinhVienIT extends SinhVien{
    private double diemJava, diemHtml, diemCSS;

    @Override
    public double getDiemTB() {
        return (2*diemJava+diemHtml+diemCSS)/4;
    }

    @Override
    public void nhap() {
        Scanner s = new Scanner(System.in);
        System.out.println("SinhVienIT: Nhap HoTen - Nganh - DiemJava - DiemHTML - DiemCSS");
        super.hoTen = s.nextLine();
        super.nganh = s.nextLine();
        this.diemJava = s.nextDouble();
        this.diemHtml = s.nextDouble();
        this.diemCSS = s.nextDouble();
        System.out.println("------Ket thuc nhap-----");
    }

    @Override
    public void xuat() {
        System.out.println("----Xuat thong tin SinhVienBiz-----");
        System.out.printf("IT: HoTen: %s - Nganh: %s - DiemJava: %.1f "
                + "- DiemHTML: %.1f - DiemCSS: %.1f - DIemTB: %.1f - HocLuc: %s",
                super.hoTen,super.nganh,this.diemJava,this.diemHtml,this.diemCSS,
                this.getDiemTB(),super.getHocLuc());
    }
    
    
}
