
package demo7;

import demo6.SanPham;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;


public class L7 {
    public static void main(String[] args) {
          List<SinhVienBiz> arrBiz = new ArrayList<>();//tao mang san pham
          List<SinhVienIT> arrIT = new ArrayList<>();
          Scanner s = new Scanner(System.in);
          System.out.println("Moi nhap SV IT ");
        while(true)
        {   
            SinhVienIT it = new SinhVienIT();
            it.nhap();
            arrIT.add(it);
            System.out.println("Co nhap tiep khong (y/n)");
            String kq = s.nextLine();//nhan ket qua la y hoac n
            if(kq.equals("n"))//neu nguoi dung nhap n
            {
                break;//thoat khoi vong lap
            }   
        }
        //lay cac sinh vien it gioi
            System.out.println("Sinh vien IT gioi");
            for(SinhVienIT it: arrIT)
            {
                if(it.getDiemTB()>=8)
                {
                    it.xuat();
                }
            }  
    }
}
