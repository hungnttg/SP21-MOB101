
package demo7;

import java.util.Scanner;

public class SinhVienBiz extends SinhVien{
    private double diemMKT, diemSale;

    @Override
    public double getDiemTB() {
        return (2*diemMKT+diemSale)/3;
    }

    @Override
    public void nhap() {
        Scanner s = new Scanner(System.in);
        System.out.println("SinhvienBiz: Nhap hoTen - Nganh - diemMKT - diemSale");
        //this: đối tượng hiện tại (con)
        //super: cha
        //super.hoTen: kế thưa hoTen từ cha
        super.hoTen = s.nextLine();
        super.nganh = s.nextLine();
        this.diemMKT = s.nextDouble();
        this.diemSale = s.nextDouble();
        System.out.println("---------------Ket thuc nhap--------");
    }

    @Override
    public void xuat() {
        System.out.println("----Xuat thong tin SinhVienBiz-----");
        System.out.printf("HoTen: %s - Nganh: %s - DiemMKT: %.1f - DiemSale: %.1f "
                + "- DiemTB: %f - HocLuc: %s",
                super.hoTen,super.nganh,this.diemMKT,this.diemSale,
                this.getDiemTB(),super.getHocLuc());
    }
    
    
    
    
    
}
