
package demo6;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class L63 {
    public static void main(String[] args) {
        List<SinhVien> arrSV = new ArrayList<>();//tao mang san pham
        Scanner s = new Scanner(System.in);
        String partternEmail = "^[\\w-\\.]+@([\\w-]+\\.)+[\\w-]{2,4}$";
        String partternPhone = "0[0-9]{9,10}";
        String partternCMT = "[0-9]{9}";
        while(true)
        {
            System.out.println("Moi nhap Ten - Email - Phone - id: ");
            SinhVien sv = new SinhVien();
            sv.setName(s.nextLine());//nhap ten tu ban phim
            sv.setEmail(s.nextLine());//nhap cong ty tu ban phim
            if(!sv.getEmail().matches(partternEmail))//dinh dang email khong dung
            {
                System.out.println("Dinh dang email khong dung, moi nhap lai");
                continue;//bo qua lan lap cu, tiep tuc lan lap moi
            }
            sv.setPhone(s.nextLine());//nhap gia tu ban phim
            if(!sv.getPhone().matches(partternPhone))//dinh dang Phone khong dung
            {
                System.out.println("Dinh dang Phone khong dung, moi nhap lai");
                continue;//bo qua lan lap cu, tiep tuc lan lap moi
            }
            sv.setId(s.nextLine()); 
            if(!sv.getId().matches(partternCMT))//dinh dang CMT khong dung
            {
                System.out.println("Dinh dang CMT khong dung, moi nhap lai");
                continue;//bo qua lan lap cu, tiep tuc lan lap moi
            }
            arrSV.add(sv);//them sp vao mang
            s.nextLine();//lam sach luong dem  
            System.out.println("Co nhap tiep khong? (y/n)");
            String kq = s.nextLine();//nhan ket qua nhap y hoac n
            if(kq.equals("n"))//neu nhap n
            {
                break;//thoat khoi vong lap
            }
        }
        
        
    }
}
