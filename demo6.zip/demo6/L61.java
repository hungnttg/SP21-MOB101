
package demo6;

import java.util.Scanner;

public class L61 {
    public static void main(String[] args) {
        String fullname="";
        Scanner s = new Scanner(System.in);
        System.out.println("Moi ban nhap ho ten");
        fullname = s.nextLine();
        //nguyen van a => NGUYEN van A
        int kyTuTrangDauTien = fullname.indexOf(" ");//chi so cua dau cach
        int kyTuTrangCuoiCung = fullname.lastIndexOf(" ");//chi so cua dau cach cuoi cung
        //substring la lay chuoi con
        String ho = fullname.substring(0,kyTuTrangDauTien).toUpperCase();
        String ten = fullname.substring(kyTuTrangCuoiCung,fullname.length()).toUpperCase();
        String dem = fullname.substring(kyTuTrangDauTien, kyTuTrangCuoiCung);
        System.out.printf("Ho ten: %s %s %s",ho,dem,ten);
    }   
}
