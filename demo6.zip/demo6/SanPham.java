package demo6;

public class SanPham {
    private String name;
    private String comp;
    private double price;
    //Get: lấy dữ liệu về
    //Set: thiết lập dữ liệu
    //không phải viêt, nó tự sinh
    public void xuat()
    {
        System.out.println(name+" - "+comp+" - "+price);
    }

    public SanPham() {
    }

    public SanPham(String name, String comp, double price) {
        this.name = name;
        this.comp = comp;
        this.price = price;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getComp() {
        return comp;
    }

    public void setComp(String comp) {
        this.comp = comp;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }
    

    
    
}
