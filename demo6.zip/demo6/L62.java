package demo6;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class L62 {
    public static void main(String[] args) {
        List<SanPham> arrSanpham = new ArrayList<>();//tao mang san pham
        Scanner s = new Scanner(System.in);
        while(true)
        {
            System.out.println("Moi nhap Ten - Cong ty - Gia: ");
            SanPham sp = new SanPham();
            sp.setName(s.nextLine());//nhap ten tu ban phim
            sp.setComp(s.nextLine());//nhap cong ty tu ban phim
            sp.setPrice(s.nextDouble());//nhap gia tu ban phim
            arrSanpham.add(sp);//them sp vao mang
            s.nextLine();//lam sach luong dem
            System.out.println("Co nhap tiep khong? (y/n)");
            String kq = s.nextLine();//nhan ket qua nhap y hoac n
            if(kq.equals("n"))//neu nhap n
            {
                break;//thoat khoi vong lap
            }
        }
        //lay ra cac san pham Nokia
        System.out.println("Cac san pham Nokia");
        for(SanPham sp: arrSanpham)//dem cac san pham trong mang san pham
        {
            if(sp.getComp().equalsIgnoreCase("Nokia"))
            {          
                sp.xuat();
            }
        }
    }
}
