
package demo2;

import java.util.Scanner;

public class Demo21 {
    public void gptb1()//dinh nghia ham
    {
        Scanner s = new Scanner(System.in);
        //Nhap a
        System.out.println("a=");
        int a = s.nextInt();
        //Nhap b
        System.out.println("b=");
        int b = s.nextInt();
        //tinh toan
        if(a==0)
        {
            if(b==0)
            {
                System.out.println("PTVSN");
            }
            else//b khac 0
            {
                System.out.println("PT vo nghiem");
            }
        }
        else//a khac 0
        {
            float nghiem = ((float)-b/a);
            System.out.println("Nghiem la x="+ nghiem);
        }
    }
    
}
