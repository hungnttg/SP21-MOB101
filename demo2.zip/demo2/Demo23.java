
package demo2;

import java.util.Scanner;

public class Demo23 {
    public void gptb2()
    {
        Scanner s = new Scanner(System.in);
        System.out.println("a=");  int a = s.nextInt();
        System.out.println("b=");  int b = s.nextInt();
        System.out.println("c=");  int c = s.nextInt();
        float delta = b*b-4*a*c;
        if(a==0)
        {
            System.out.println("Day la PTB1");
        }
        else
        {
            if(delta<0)
            {
                System.out.println("PTVN");
            }
            else if(delta==0)
            {
                System.out.println("PT co n duy nhat x="+(float)(-b/(2*a)));
            }
            else
            {
                float x1 = ((float)(-b-Math.sqrt(delta)/(2*a)));
                float x2 = ((float)(-b+Math.sqrt(delta)/(2*a)));
                System.out.println("2 nghiem x1="+x1);
                System.out.println(" va x2="+x2);
            }
        }
    } 
    public void gptb1()//dinh nghia ham
    {
        Scanner s = new Scanner(System.in);
        //Nhap a
        System.out.println("a=");
        int a = s.nextInt();
        //Nhap b
        System.out.println("b=");
        int b = s.nextInt();
        //tinh toan
        if(a==0)
        {
            if(b==0)
            {
                System.out.println("PTVSN");
            }
            else//b khac 0
            {
                System.out.println("PT vo nghiem");
            }
        }
        else//a khac 0
        {
            float nghiem = ((float)-b/a);
            System.out.println("Nghiem la x="+ nghiem);
        }
    }
    public void menu()
    {
        System.out.println("Moi ban chon chuc nang");
        System.out.println("-----------------------");
        System.out.println("1. Giai phuong trinh bac 1");
        System.out.println("2. Giai phuong trinh bac 2");
        System.out.println("-----------------------");
        Scanner s = new Scanner(System.in);
        int traloi = s.nextInt();
        switch(traloi)
        {
            case 1:
                gptb1();
                break;
            case 2:
                gptb2();
                break;
            default:
                System.out.println("Khong co chuc nang ban vua nhap");
                break;                      
        }     
    }
}
