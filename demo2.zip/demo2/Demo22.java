
package demo2;

import java.util.Scanner;

public class Demo22 {
    public void gptb2()
    {
        Scanner s = new Scanner(System.in);
        System.out.println("a=");  int a = s.nextInt();
        System.out.println("b=");  int b = s.nextInt();
        System.out.println("c=");  int c = s.nextInt();
        float delta = b*b-4*a*c;
        if(a==0)
        {
            System.out.println("Day la PTB1");
        }
        else
        {
            if(delta<0)
            {
                System.out.println("PTVN");
            }
            else if(delta==0)
            {
                System.out.println("PT co n duy nhat x="+(float)(-b/(2*a)));
            }
            else
            {
                float x1 = ((float)(-b-Math.sqrt(delta)/(2*a)));
                float x2 = ((float)(-b+Math.sqrt(delta)/(2*a)));
                System.out.println("2 nghiem x1="+x1);
                System.out.println(" va x2="+x2);
            }
        }
    }   
}
