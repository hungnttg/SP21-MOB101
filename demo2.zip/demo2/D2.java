
package demo2;

public class D2 {
    public static void main(String[] args) {
        //Demo21 d21 = new Demo21();//Scanner s = new Scanner();
        //d21.gptb1();//s.nextInt();
        
        //Demo22 d22 = new Demo22();
        //d22.gptb2();
        
        Demo23 d23 = new Demo23();
        d23.menu();
    }
}
