
package demomob101;

import java.util.Scanner;

public class Lab12 {
    //1.dinh nghia ham
    public static void tinhChuVi_DienTich()
    {
        Scanner s = new Scanner(System.in);
        //-Nhap chieu dai
        System.out.println("Chieu dai=");
        double dai = s.nextDouble();
        //-Nhap chieu rong
        System.out.println("Chieu rong=");
        double rong = s.nextDouble();
        //tinh 
        double chuvi = (dai+rong)*2;
        double dientich = dai*rong;
        //in
        System.out.println("Chu vi la "+ chuvi);
        System.out.println("Dien tich la "+ dientich);
    }
    public static void main(String[] args) {
        tinhChuVi_DienTich();//goi ham
    }
}
