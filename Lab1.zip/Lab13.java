
package demomob101;

import java.util.Scanner;

public class Lab13 {
    public static void LapPhuong()
    {
        Scanner s = new Scanner(System.in);
        System.out.println("Nhap canh=");
        double canh = s.nextDouble();
        double thetich = Math.pow(canh, 3);
        System.out.println("The tich la: "+thetich);
    }
    public static void main(String[] args) {
        LapPhuong();
    }
}
