
package demomob101;//tên package (gói) (giống tòa nhà F,P,L)

import java.util.Scanner;
public class DemoMob101 {//tên class (giống tên lớp CP17316,CP17317) 
 
    public static void main(String[] args) {//hàm main (giống trong C)
        Scanner s = new Scanner(System.in);//chi tao 1 lan
        //---Nhap ho ten
        System.out.println("Ho ten");
        String hoVaTen = s.nextLine();
        //--Nhap diem
        System.out.println("Diem");
        double diem = s.nextDouble();
        //--In ra man hinh
        System.out.println("Ban vua nhap");
        System.out.printf("%s %.1f diem",hoVaTen,diem);
        
    }
    
}
