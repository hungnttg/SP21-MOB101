
package demomob101;

import java.util.Scanner;

public class Lab14 {
    public static void gptb2()
    {
        Scanner s = new Scanner(System.in);
        System.out.println("a=");
        int a = s.nextInt();
        System.out.println("b=");
        int b = s.nextInt();
        System.out.println("c=");
        int c = s.nextInt();
        //tinh
        float delta = b*b-4*a*c;
        if(a==0)
        {
            System.out.println("Day la ptb1");
        }
        else
        {
            if(delta<0)
            {
                System.out.println("PTVN");
            }
            else if(delta==0)
            {
                System.out.println("nghiem kep x="+(float)(-b)/(2*a));
            }
            else
            {
                System.out.println("x1="+(float)(-b+Math.sqrt(delta)/(2*a)));
                System.out.println("x2="+(float)(-b-Math.sqrt(delta)/(2*a)));
            }
        }
    }
    public static void main(String[] args) {
        gptb2();
    }
 
}
