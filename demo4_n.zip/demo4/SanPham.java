/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package demo4;

import java.util.Scanner;

public class SanPham {
    //1.Dinh nghia cac bien
    public String tenSP;
    public double donGia;
    public double giamGia;
    //2.dinh nghia cac ham
    public double thueNhapKhau()
    {
        double tnk = donGia*0.1;
        return tnk;
    }
    public void xuat()
    {
        System.out.println("Thong tin san pham vua nhap");
        System.out.println("Ten san pham: "+tenSP);
        System.out.println("Don gia: "+donGia);
        System.out.println("Giam gia: "+giamGia);
        System.out.println("Thue nhap khau: "+thueNhapKhau());
    }
    public void nhap()
    {
        System.out.println("Moi nhap: Ten,DonGia,GiamGia");
        Scanner s = new Scanner(System.in);
        tenSP = s.nextLine();
        donGia = Double.parseDouble(s.nextLine());
        giamGia = Double.parseDouble(s.nextLine());
    }
    //3. Dinh nghia hàm khoi tao
    public SanPham()
    {}
}
