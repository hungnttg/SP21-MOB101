
package demo4;

import java.util.Scanner;


public class Product {
    private String tenSP;
    private double donGia;
    private double giamGia;
    ///------------
    public double thueNhapKhau()
    {
        double tnk = donGia*0.1;
        return tnk;
    }
    public void xuat()
    {
        System.out.println("Thong tin san pham vua nhap");
        System.out.println("Ten san pham: "+tenSP);
        System.out.println("Don gia: "+donGia);
        System.out.println("Giam gia: "+giamGia);
        System.out.println("Thue nhap khau: "+thueNhapKhau());
    }
    public void nhap()
    {
        System.out.println("Moi nhap: Ten,DonGia,GiamGia");
        Scanner s = new Scanner(System.in);
        tenSP = s.nextLine();
        donGia = Double.parseDouble(s.nextLine());
        giamGia = Double.parseDouble(s.nextLine());
    }
    ///------------

    public Product() {
    }

    public Product(String tenSP, double donGia, double giamGia) {
        this.tenSP = tenSP;
        this.donGia = donGia;
        this.giamGia = giamGia;
    }

    public String getTenSP() {
        return tenSP;
    }

    public void setTenSP(String tenSP) {
        this.tenSP = tenSP;
    }

    public double getDonGia() {
        return donGia;
    }

    public void setDonGia(double donGia) {
        this.donGia = donGia;
    }

    public double getGiamGia() {
        return giamGia;
    }

    public void setGiamGia(double giamGia) {
        this.giamGia = giamGia;
    }
    
}
