package demo4;//tòa nhà F,P,L
//lớp học ở trong tòa nhà; mỗi lớp học chứa nhiều sv (đối tượng)
public class D4 {
    public static void main(String[] args) {
        //demo1+demo2---------
//        SanPham s1 = new SanPham();
//        s1.nhap();
//        s1.xuat();
          //demo3------------
          //goi ham khoi tao co tham so
          //giong nhu: Scanner s = new Scanner(System.in);
          //SanPham1 sp1 = new SanPham1("IPhone 13",310000);
          //sp1.xuat();
          Product p = new Product();
          p.nhap();
          p.xuat();
    }
}
