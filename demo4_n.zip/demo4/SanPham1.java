
package demo4;

import java.util.Scanner;



public class SanPham1 {
     private String tenSP;
     private double donGia;
     private double giamGia;
    //--------------------------------------------
     public double thueNhapKhau()
    {
        double tnk = donGia*0.1;
        return tnk;
    }
    public void xuat()
    {
        System.out.println("Thong tin san pham vua nhap");
        System.out.println("Ten san pham: "+tenSP);
        System.out.println("Don gia: "+donGia);
        System.out.println("Giam gia: "+giamGia);
        System.out.println("Thue nhap khau: "+thueNhapKhau());
    }
    public void nhap()
    {
        System.out.println("Moi nhap: Ten,DonGia,GiamGia");
        Scanner s = new Scanner(System.in);
        tenSP = s.nextLine();
        donGia = Double.parseDouble(s.nextLine());
        giamGia = Double.parseDouble(s.nextLine());
    }
     //---------------------------------------------
    //1
    public SanPham1() {
    }
    //2
    public SanPham1(String tenSP, double donGia, double giamGia) {
        this.tenSP = tenSP;
        this.donGia = donGia;
        this.giamGia = giamGia;
    }
    //3
    public SanPham1(String tenSP, double donGia) {
        this(tenSP,donGia,0);//ham 3 goi ham 2
    }
    
    //get: xuat
    //set: nhap
    public String getTenSP() {//Hàm Xuat ten san pham
        return tenSP;
    }

    public void setTenSP(String tenSP) {//Ham nhap ten san pham
        this.tenSP = tenSP;
    }

    public double getDonGia() {//Ham xuat don gia
        return donGia;
    }

    public void setDonGia(double donGia) {//ham nhap don gia
        this.donGia = donGia;
    }

    public double getGiamGia() {//Ham xuat giam gia
        return giamGia;
    }

    public void setGiamGia(double giamGia) {//ham nhap giam gia
        this.giamGia = giamGia;
    }
     
}
