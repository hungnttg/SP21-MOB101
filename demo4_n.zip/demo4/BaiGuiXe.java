
package demo4;

public class BaiGuiXe {
    //dinh nghia cac bien
    public String mauSon;
    public String hangXe;
    public int soBanh;
    //Dinh nghia cac ham
    public void di()
    {
        System.out.println("Xe co the di thang, re phai, re trai");
    }
    public void no()
    {
        System.out.println("Xe no bruwm");
    }
}
